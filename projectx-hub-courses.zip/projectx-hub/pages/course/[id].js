import { useEffect, useState } from "react";
import Head from "next/head";
import Link from "next/link";
import { useRouter } from "next/router";
import Navbar from "../../components/Navbar";
import ProgressBar from "../../components/ProgressBar";
import LessonView from "../../components/LessonView";
import QuizView from "../../components/QuizView";
import CertificateCard from "../../components/CertificateCard";
import PaywallModal from "../../components/PaywallModal";
import { getAllCourses, getCourseById } from "../../data/courses";
import {
  getProgress, markLessonComplete, getCompletionPercent,
  recordQuizResult, isUnlocked, unlockCourse, issueCertificate,
} from "../../lib/progress";
import { ArrowLeft, Lock, Clock, BarChart3, Copy, Check } from "lucide-react";

const UNLOCK_QUIZ_AT = 80; // percent

export async function getStaticPaths() {
  const courses = getAllCourses();
  return { paths: courses.map(c => ({ params: { id: c.id } })), fallback: false };
}

export async function getStaticProps({ params }) {
  const course = getCourseById(params.id);
  if (!course) return { notFound: true };
  return { props: { course } };
}

export default function CoursePage({ course }) {
  const router = useRouter();
  const [progress, setProgress] = useState({ completedLessons: [], quizPassed: false, quizScore: null });
  const [unlocked, setUnlocked] = useState(!course.premium);
  const [showPaywall, setShowPaywall] = useState(false);
  const [stage, setStage] = useState("lessons"); // lessons | quiz | certificate
  const [name, setName] = useState("");
  const [cert, setCert] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setProgress(getProgress(course.id));
    setUnlocked(isUnlocked(course.id, course.premium));
  }, [course.id, course.premium]);

  const percent = getCompletionPercent(course.id, course.lessons.length);
  const canTakeQuiz = percent >= UNLOCK_QUIZ_AT;

  function handleLessonComplete(index) {
    const updated = markLessonComplete(course.id, index);
    setProgress(updated);
  }

  function handleUnlock() {
    unlockCourse(course.id);
    setUnlocked(true);
    setShowPaywall(false);
  }

  function handleQuizFinish(score, total, passed) {
    const result = recordQuizResult(course.id, score, total);
    setProgress(p => ({ ...p, quizPassed: result.passed, quizScore: { score, total } }));
    if (result.passed) setStage("certificate-form");
  }

  function handleIssueCertificate() {
    if (!name.trim()) return;
    const c = issueCertificate({ courseId: course.id, courseTitle: course.title, track: course.track, name: name.trim() });
    setCert(c);
    setStage("certificate");
  }

  function copyLink() {
    const link = `${typeof window !== "undefined" ? window.location.origin : "projectxhub.com"}/verify?id=${cert.id}`;
    navigator.clipboard?.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (!unlocked) {
    return (
      <div className="min-h-screen bg-brand-surface">
        <Navbar />
        <main className="max-w-2xl mx-auto px-5 py-16 text-center">
          <div className="h-14 w-14 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-5">
            <Lock size={24} className="text-brand-amber" />
          </div>
          <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: course.trackColor }}>{course.track}</p>
          <h1 className="font-display text-3xl font-bold text-brand-ink mt-2 mb-3">{course.title}</h1>
          <p className="text-brand-sub mb-8 max-w-md mx-auto leading-relaxed">{course.blurb}</p>
          <button
            onClick={() => setShowPaywall(true)}
            className="bg-brand-blue text-white font-semibold text-sm px-6 py-3 rounded-full hover:bg-blue-700 transition-colors"
          >
            Unlock this course
          </button>
        </main>
        {showPaywall && <PaywallModal course={course} onClose={() => setShowPaywall(false)} onUnlock={handleUnlock} />}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-surface">
      <Head>
        <title>{course.title} — ProjectX Hub</title>
      </Head>
      <Navbar />

      <main className="max-w-4xl mx-auto px-5 py-8">
        <button onClick={() => router.push("/")} className="flex items-center gap-1.5 text-sm text-brand-sub hover:text-brand-ink mb-6 transition-colors">
          <ArrowLeft size={15} /> All courses
        </button>

        <div className="mb-6">
          <p className="text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: course.trackColor }}>{course.track}</p>
          <h1 className="font-display text-3xl font-bold text-brand-ink mb-2">{course.title}</h1>
          <p className="text-brand-sub mb-4">{course.blurb}</p>
          <div className="flex items-center gap-4 text-xs text-brand-sub">
            <span className="flex items-center gap-1"><Clock size={13} /> {course.hours}h</span>
            <span className="flex items-center gap-1"><BarChart3 size={13} /> {course.level}</span>
          </div>
        </div>

        <div className="bg-white border border-brand-line rounded-2xl p-5 mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-brand-ink">Your progress</span>
            <span className="text-sm text-brand-sub">{percent}%</span>
          </div>
          <ProgressBar percent={percent} color={course.trackColor} />
          <p className="text-xs text-brand-sub mt-2">
            {canTakeQuiz ? "You've unlocked the certificate quiz." : `Complete ${UNLOCK_QUIZ_AT}% of the lessons to unlock the certificate quiz.`}
          </p>
        </div>

        {stage === "lessons" && (
          <>
            <LessonView course={course} completedLessons={progress.completedLessons} onComplete={handleLessonComplete} />
            <div className="mt-8 flex justify-center">
              <button
                onClick={() => setStage("quiz")}
                disabled={!canTakeQuiz}
                className="bg-brand-blue text-white font-semibold text-sm px-6 py-3 rounded-full hover:bg-blue-700 transition-colors disabled:bg-brand-line disabled:text-brand-sub disabled:cursor-not-allowed"
              >
                {canTakeQuiz ? "Take the certificate quiz →" : `Reach ${UNLOCK_QUIZ_AT}% to unlock the quiz`}
              </button>
            </div>
          </>
        )}

        {stage === "quiz" && (
          <div>
            <h2 className="font-display text-xl font-bold text-brand-ink mb-1">Certificate Quiz</h2>
            <p className="text-sm text-brand-sub mb-6">Score {Math.ceil(course.quiz.length * 0.7)}/{course.quiz.length} or higher to earn your certificate.</p>
            <QuizView quiz={course.quiz} onFinish={handleQuizFinish} />
            <button onClick={() => setStage("lessons")} className="mt-6 text-sm text-brand-sub hover:text-brand-ink flex items-center gap-1.5">
              <ArrowLeft size={14} /> Back to lessons
            </button>
          </div>
        )}

        {stage === "certificate-form" && (
          <div className="max-w-md mx-auto bg-white border border-brand-line rounded-2xl p-7 text-center">
            <p className="text-brand-green text-sm font-semibold mb-1">Quiz passed 🎉</p>
            <h2 className="font-display text-xl font-bold text-brand-ink mb-4">Almost done — enter your name</h2>
            <p className="text-sm text-brand-sub mb-4">This is exactly how it'll appear on your certificate.</p>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Your full name"
              className="w-full bg-brand-surface border border-brand-line rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-blue mb-4"
            />
            <button
              onClick={handleIssueCertificate}
              disabled={!name.trim()}
              className="w-full bg-brand-blue text-white font-semibold text-sm py-3 rounded-full hover:bg-blue-700 transition-colors disabled:bg-brand-line disabled:text-brand-sub"
            >
              Generate my certificate
            </button>
          </div>
        )}

        {stage === "certificate" && cert && (
          <div className="max-w-lg mx-auto">
            <CertificateCard cert={cert} />
            <div className="bg-white border border-brand-line rounded-xl p-4 mt-5 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs text-brand-sub mb-0.5">Verification link</p>
                <p className="font-mono text-sm text-brand-ink truncate">/verify?id={cert.id}</p>
              </div>
              <button onClick={copyLink} className="shrink-0 flex items-center gap-1.5 text-xs font-semibold bg-brand-surface border border-brand-line rounded-full px-3 py-2 hover:bg-blue-50 hover:text-brand-blue transition-colors">
                {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Copied" : "Copy link"}
              </button>
            </div>
            <div className="text-center mt-6">
              <Link href="/" className="text-sm text-brand-blue hover:underline">← Explore more courses</Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
