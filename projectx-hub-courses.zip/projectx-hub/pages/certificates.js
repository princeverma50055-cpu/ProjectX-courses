import { useEffect, useState } from "react";
import Head from "next/head";
import Link from "next/link";
import Navbar from "../components/Navbar";
import { getMyCertificates } from "../lib/progress";
import { Award } from "lucide-react";

export default function Certificates() {
  const [certs, setCerts] = useState([]);

  useEffect(() => {
    setCerts(getMyCertificates());
  }, []);

  return (
    <div className="min-h-screen bg-brand-surface">
      <Head><title>My Certificates — ProjectX Hub</title></Head>
      <Navbar />
      <main className="max-w-3xl mx-auto px-5 py-12">
        <h1 className="font-display text-2xl font-bold text-brand-ink mb-1">My certificates</h1>
        <p className="text-sm text-brand-sub mb-8">Earned on this device.</p>

        {certs.length === 0 ? (
          <div className="text-center py-16 bg-white border border-dashed border-brand-line rounded-2xl">
            <Award size={28} className="text-brand-sub mx-auto mb-3" />
            <p className="text-brand-sub text-sm mb-4">No certificates yet — finish a course to earn your first one.</p>
            <Link href="/" className="text-brand-blue text-sm font-semibold hover:underline">Browse courses →</Link>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {certs.map(c => (
              <Link key={c.id} href={`/verify?id=${c.id}`} className="bg-white border border-brand-line rounded-2xl p-5 hover:shadow-raised transition-shadow">
                <p className="text-xs font-semibold text-brand-blue uppercase tracking-wide mb-1">{c.track}</p>
                <h3 className="font-display font-bold text-brand-ink mb-1">{c.courseTitle}</h3>
                <p className="text-xs text-brand-sub mb-3">{c.date}</p>
                <p className="font-mono text-xs text-brand-sub">{c.id}</p>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
