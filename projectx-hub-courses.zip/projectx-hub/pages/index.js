import { useMemo, useState } from "react";
import Head from "next/head";
import Navbar from "../components/Navbar";
import CourseCard from "../components/CourseCard";
import { getAllCourses, getTracks } from "../data/courses";
import { Search } from "lucide-react";

export async function getStaticProps() {
  const courses = getAllCourses();
  const tracks = getTracks();
  return { props: { courses, tracks } };
}

export default function Home({ courses, tracks }) {
  const [query, setQuery] = useState("");
  const [track, setTrack] = useState("All");
  const [level, setLevel] = useState("All");

  const filtered = useMemo(() => {
    return courses.filter(c => {
      const matchesQuery = !query || c.title.toLowerCase().includes(query.toLowerCase()) || c.track.toLowerCase().includes(query.toLowerCase());
      const matchesTrack = track === "All" || c.track === track;
      const matchesLevel = level === "All" || c.level === level;
      return matchesQuery && matchesTrack && matchesLevel;
    });
  }, [courses, query, track, level]);

  return (
    <div className="min-h-screen bg-brand-surface">
      <Head>
        <title>ProjectX Hub — 500+ Courses with Verified Certificates</title>
        <meta name="description" content="Learn from 500+ self-paced courses on ProjectX Hub. Complete 80% of any course, pass a 10-question quiz, and earn a verifiable certificate." />
      </Head>
      <Navbar />

      <main className="max-w-6xl mx-auto px-5 py-10">
        <section className="mb-10">
          <p className="text-sm font-semibold text-brand-blue mb-2">{courses.length}+ courses · self-paced · certified</p>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-brand-ink tracking-tight mb-3 max-w-2xl">
            Learn something real. Finish it. Prove it.
          </h1>
          <p className="text-brand-sub text-base max-w-xl leading-relaxed">
            Every course on ProjectX Hub is self-paced. Complete 80% of the lessons, pass a 10-question
            quiz, and get a certificate with a unique ID anyone can verify.
          </p>
        </section>

        <section className="sticky top-16 z-20 bg-brand-surface/95 backdrop-blur pt-2 pb-4 -mx-5 px-5 mb-2">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-sub" />
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search 500+ courses…"
                className="w-full bg-white border border-brand-line rounded-full pl-11 pr-4 py-3 text-sm outline-none focus:border-brand-blue focus:ring-2 focus:ring-blue-100 transition-all placeholder:text-brand-sub"
              />
            </div>
            <select
              value={track}
              onChange={e => setTrack(e.target.value)}
              className="bg-white border border-brand-line rounded-full px-4 py-3 text-sm text-brand-ink outline-none focus:border-brand-blue"
            >
              <option value="All">All tracks</option>
              {tracks.map(t => <option key={t.key} value={t.name}>{t.name}</option>)}
            </select>
            <select
              value={level}
              onChange={e => setLevel(e.target.value)}
              className="bg-white border border-brand-line rounded-full px-4 py-3 text-sm text-brand-ink outline-none focus:border-brand-blue"
            >
              <option value="All">All levels</option>
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </div>
          <p className="text-xs text-brand-sub mt-3">{filtered.length} courses match your filters</p>
        </section>

        <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.slice(0, 60).map(course => (
            <CourseCard key={course.id} course={course} />
          ))}
        </section>

        {filtered.length > 60 && (
          <p className="text-center text-sm text-brand-sub mt-8">
            Showing 60 of {filtered.length} results — narrow your search to see more specific courses.
          </p>
        )}
        {filtered.length === 0 && (
          <p className="text-center text-brand-sub py-16">No courses match that search. Try a different term or track.</p>
        )}
      </main>

      <footer className="border-t border-brand-line py-8 text-center">
        <p className="text-xs text-brand-sub">ProjectX Hub · Ideas are easy. Execution is everything.</p>
      </footer>
    </div>
  );
}
