import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Navbar from "../components/Navbar";
import CertificateCard from "../components/CertificateCard";
import { getCertificate } from "../lib/progress";
import { ShieldCheck, XCircle } from "lucide-react";

export default function Verify() {
  const router = useRouter();
  const [input, setInput] = useState("");
  const [result, setResult] = useState(undefined); // undefined = not searched yet

  useEffect(() => {
    if (router.query.id) {
      setInput(router.query.id);
      runVerify(router.query.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router.query.id]);

  function runVerify(idOverride) {
    const id = (idOverride || input).trim().toUpperCase();
    if (!id) return;
    setResult(getCertificate(id) || null);
  }

  return (
    <div className="min-h-screen bg-brand-surface">
      <Head><title>Verify a Certificate — ProjectX Hub</title></Head>
      <Navbar />
      <main className="max-w-lg mx-auto px-5 py-12">
        <div className="flex items-center gap-2 mb-2">
          <ShieldCheck size={22} className="text-brand-blue" />
          <h1 className="font-display text-2xl font-bold text-brand-ink">Verify a certificate</h1>
        </div>
        <p className="text-sm text-brand-sub mb-6">Enter a certificate ID (like PXH-XXXX-XXXX-XX) to confirm it's real.</p>

        <div className="flex gap-2 mb-8">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && runVerify()}
            placeholder="PXH-XXXX-XXXX-XX"
            className="flex-1 font-mono bg-white border border-brand-line rounded-full px-5 py-3 text-sm outline-none focus:border-brand-blue"
          />
          <button onClick={() => runVerify()} className="bg-brand-blue text-white font-semibold text-sm px-5 rounded-full hover:bg-blue-700 transition-colors">
            Verify
          </button>
        </div>

        {result === null && (
          <div className="border border-red-100 bg-red-50 rounded-2xl p-6 text-center">
            <XCircle size={22} className="text-brand-red mx-auto mb-2" />
            <p className="text-brand-red font-semibold text-sm">No certificate found</p>
            <p className="text-brand-sub text-xs mt-1">Double-check the ID and try again.</p>
          </div>
        )}

        {result && <CertificateCard cert={result} />}

        <p className="text-xs text-brand-sub mt-8 leading-relaxed">
          Note: this demo stores certificates in your browser. To verify certificates across
          different devices in production, connect this to a shared database — see the README
          for the Supabase upgrade path.
        </p>
      </main>
    </div>
  );
}
