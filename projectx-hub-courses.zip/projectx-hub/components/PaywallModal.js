import { useState } from "react";
import { Lock, X, IndianRupee, CheckCircle2 } from "lucide-react";

// This is a working UI stub for the unlock flow. It calls onUnlock() directly
// once the person confirms payment. To go live, replace the "I've Paid — Unlock"
// button's onClick with a real verification step:
//   1. Show your UPI QR / Razorpay checkout instead of (or alongside) this modal.
//   2. On payment success webhook (server-side), mark the course unlocked
//      against the user's account in your database (e.g. Supabase).
//   3. Call onUnlock() only after that server-side confirmation, not on trust.

const PRICE = 199;

export default function PaywallModal({ course, onClose, onUnlock }) {
  const [confirming, setConfirming] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-sm w-full p-6 relative" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-brand-sub hover:text-brand-ink">
          <X size={18} />
        </button>

        <div className="h-12 w-12 rounded-full bg-amber-50 flex items-center justify-center mb-4">
          <Lock size={20} className="text-brand-amber" />
        </div>
        <h3 className="font-display text-lg font-bold text-brand-ink mb-1">Unlock this course</h3>
        <p className="text-sm text-brand-sub mb-5 leading-relaxed">
          <span className="font-medium text-brand-ink">{course.title}</span> is a premium course.
          Unlock it once, keep it forever — including the certificate on completion.
        </p>

        <div className="flex items-center justify-center gap-1 text-3xl font-display font-bold text-brand-ink mb-6">
          <IndianRupee size={22} className="mt-1" />{PRICE}
        </div>

        {!confirming ? (
          <button
            onClick={() => setConfirming(true)}
            className="w-full bg-brand-blue text-white font-semibold text-sm py-3 rounded-full hover:bg-blue-700 transition-colors"
          >
            Pay with UPI
          </button>
        ) : (
          <div className="text-center">
            <div className="h-40 w-40 mx-auto mb-4 rounded-xl border border-dashed border-brand-line flex items-center justify-center text-xs text-brand-sub bg-brand-surface">
              UPI QR goes here
            </div>
            <p className="text-xs text-brand-sub mb-4">Scan and pay, then confirm below.</p>
            <button
              onClick={onUnlock}
              className="w-full flex items-center justify-center gap-2 bg-brand-green text-white font-semibold text-sm py-3 rounded-full hover:bg-green-700 transition-colors"
            >
              <CheckCircle2 size={16} /> I've Paid — Unlock Course
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
