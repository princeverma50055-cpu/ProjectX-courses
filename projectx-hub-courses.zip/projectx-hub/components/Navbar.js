import Link from "next/link";
import { Sparkles, ShieldCheck, Award } from "lucide-react";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-brand-line">
      <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <div className="h-8 w-8 rounded-lg bg-brand-blue flex items-center justify-center">
            <Sparkles size={16} className="text-white" strokeWidth={2.5} />
          </div>
          <span className="font-display font-bold text-lg text-brand-ink tracking-tight">
            ProjectX <span className="text-brand-blue">Hub</span>
          </span>
        </Link>
        <nav className="flex items-center gap-1 text-sm font-medium">
          <Link href="/" className="px-3 py-2 rounded-full text-brand-sub hover:bg-brand-surface hover:text-brand-ink transition-colors">
            Courses
          </Link>
          <Link href="/certificates" className="px-3 py-2 rounded-full text-brand-sub hover:bg-brand-surface hover:text-brand-ink transition-colors flex items-center gap-1.5">
            <Award size={15} /> My Certificates
          </Link>
          <Link href="/verify" className="px-3 py-2 rounded-full text-brand-sub hover:bg-brand-surface hover:text-brand-ink transition-colors flex items-center gap-1.5">
            <ShieldCheck size={15} /> Verify
          </Link>
        </nav>
      </div>
    </header>
  );
}
