import { useState } from "react";
import { CheckCircle2, XCircle, RotateCcw } from "lucide-react";

const PASS_THRESHOLD = 0.7; // 7 out of 10

export default function QuizView({ quiz, onFinish }) {
  const [answers, setAnswers] = useState(Array(quiz.length).fill(null));
  const [submitted, setSubmitted] = useState(false);

  const allAnswered = answers.every(a => a !== null);
  const score = submitted ? answers.filter((a, i) => a === quiz[i].correct).length : 0;
  const passed = submitted && score / quiz.length >= PASS_THRESHOLD;

  function selectAnswer(qIndex, optIndex) {
    if (submitted) return;
    const next = [...answers];
    next[qIndex] = optIndex;
    setAnswers(next);
  }

  function submit() {
    if (!allAnswered) return;
    setSubmitted(true);
    onFinish(score, quiz.length, score / quiz.length >= PASS_THRESHOLD);
  }

  function retry() {
    setAnswers(Array(quiz.length).fill(null));
    setSubmitted(false);
  }

  if (submitted) {
    return (
      <div className="bg-white border border-brand-line rounded-2xl p-8 text-center animate-fade-in">
        <div className={`h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4 ${passed ? "bg-green-50" : "bg-red-50"}`}>
          {passed ? <CheckCircle2 size={30} className="text-brand-green" /> : <XCircle size={30} className="text-brand-red" />}
        </div>
        <h2 className="font-display text-2xl font-bold text-brand-ink mb-1">
          You scored {score} / {quiz.length}
        </h2>
        <p className="text-brand-sub mb-6">
          {passed
            ? "You passed — your certificate is ready below."
            : `You need at least ${Math.ceil(quiz.length * PASS_THRESHOLD)}/${quiz.length} to pass. Review the lessons and try again.`}
        </p>
        {!passed && (
          <button
            onClick={retry}
            className="inline-flex items-center gap-2 bg-brand-blue text-white font-semibold text-sm px-5 py-2.5 rounded-full hover:bg-blue-700 transition-colors"
          >
            <RotateCcw size={15} /> Retake the quiz
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {quiz.map((item, qi) => (
        <div key={qi} className="bg-white border border-brand-line rounded-2xl p-6">
          <p className="text-xs font-semibold text-brand-blue mb-1.5">Question {qi + 1} of {quiz.length}</p>
          <h3 className="font-display font-bold text-brand-ink text-[15px] mb-4 leading-snug">{item.q}</h3>
          <div className="grid gap-2">
            {item.options.map((opt, oi) => {
              const selected = answers[qi] === oi;
              return (
                <button
                  key={oi}
                  onClick={() => selectAnswer(qi, oi)}
                  className={`text-left px-4 py-3 rounded-xl border text-sm transition-colors ${
                    selected ? "border-brand-blue bg-blue-50 text-brand-ink font-medium" : "border-brand-line text-brand-ink/90 hover:border-brand-blue/40 hover:bg-brand-surface"
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
        </div>
      ))}

      <button
        onClick={submit}
        disabled={!allAnswered}
        className="w-full bg-brand-blue text-white font-semibold text-sm py-3.5 rounded-full hover:bg-blue-700 transition-colors disabled:bg-brand-line disabled:text-brand-sub disabled:cursor-not-allowed"
      >
        {allAnswered ? "Submit quiz" : `Answer all ${quiz.length} questions to submit`}
      </button>
    </div>
  );
}
