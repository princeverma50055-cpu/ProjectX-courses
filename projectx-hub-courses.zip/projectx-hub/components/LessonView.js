import { useState } from "react";
import { CheckCircle2, Circle, ChevronRight } from "lucide-react";

export default function LessonView({ course, completedLessons, onComplete }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const lesson = course.lessons[activeIndex];
  const isDone = completedLessons.includes(activeIndex);

  return (
    <div className="grid md:grid-cols-[260px_1fr] gap-6">
      {/* Sidebar: lesson list */}
      <aside className="md:sticky md:top-24 h-fit">
        <p className="text-xs font-semibold uppercase tracking-wide text-brand-sub mb-3 px-1">
          {course.lessons.length} Lessons
        </p>
        <ol className="space-y-1">
          {course.lessons.map((l, i) => {
            const done = completedLessons.includes(i);
            const active = i === activeIndex;
            return (
              <li key={i}>
                <button
                  onClick={() => setActiveIndex(i)}
                  className={`w-full text-left flex items-start gap-2.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${
                    active ? "bg-blue-50 text-brand-blue font-medium" : "text-brand-ink hover:bg-brand-surface"
                  }`}
                >
                  {done ? (
                    <CheckCircle2 size={16} className="text-brand-green mt-0.5 shrink-0" />
                  ) : (
                    <Circle size={16} className="text-brand-line mt-0.5 shrink-0" />
                  )}
                  <span className="leading-snug">{l.title}</span>
                </button>
              </li>
            );
          })}
        </ol>
      </aside>

      {/* Lesson content */}
      <article className="bg-white border border-brand-line rounded-2xl p-6 md:p-8 animate-fade-in">
        <p className="text-xs font-semibold uppercase tracking-wide text-brand-blue mb-2">
          Lesson {activeIndex + 1} of {course.lessons.length}
        </p>
        <h2 className="font-display text-2xl font-bold text-brand-ink mb-5">{lesson.title}</h2>
        <div className="space-y-4 text-[15px] leading-[1.75] text-brand-ink/90">
          {lesson.content.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>

        <div className="flex items-center justify-between mt-8 pt-6 border-t border-brand-line">
          <button
            onClick={() => onComplete(activeIndex)}
            disabled={isDone}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-semibold transition-colors ${
              isDone
                ? "bg-green-50 text-brand-green cursor-default"
                : "bg-brand-blue text-white hover:bg-blue-700"
            }`}
          >
            <CheckCircle2 size={16} /> {isDone ? "Lesson completed" : "Mark as complete"}
          </button>

          {activeIndex < course.lessons.length - 1 && (
            <button
              onClick={() => setActiveIndex(activeIndex + 1)}
              className="flex items-center gap-1 text-sm font-medium text-brand-sub hover:text-brand-blue transition-colors"
            >
              Next lesson <ChevronRight size={16} />
            </button>
          )}
        </div>
      </article>
    </div>
  );
}
