export default function ProgressBar({ percent, color = "#1A73E8" }) {
  return (
    <div className="w-full h-2 bg-brand-line rounded-full overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-500 ease-out"
        style={{ width: `${Math.min(100, Math.max(0, percent))}%`, backgroundColor: color }}
      />
    </div>
  );
}
