import { Award, Sparkles } from "lucide-react";

export default function CertificateCard({ cert }) {
  return (
    <div className="relative bg-white border-2 border-brand-blue/15 rounded-2xl p-8 md:p-10 overflow-hidden">
      <div className="absolute -top-16 -right-16 h-56 w-56 rounded-full bg-blue-50" />
      <div className="absolute -bottom-16 -left-16 h-56 w-56 rounded-full bg-amber-50" />
      <div className="relative">
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-brand-blue flex items-center justify-center">
              <Sparkles size={16} className="text-white" strokeWidth={2.5} />
            </div>
            <span className="font-display font-bold text-brand-ink">ProjectX Hub</span>
          </div>
          <Award size={28} className="text-brand-blue" />
        </div>

        <p className="text-xs font-semibold uppercase tracking-widest text-brand-sub mb-2">
          Certificate of Completion
        </p>
        <h2 className="font-display text-3xl font-bold text-brand-ink mb-5">{cert.name}</h2>
        <p className="text-sm text-brand-sub mb-1">has successfully completed the course</p>
        <p className="font-display text-xl font-bold text-brand-blue mb-1">{cert.courseTitle}</p>
        <p className="text-xs text-brand-sub mb-8">{cert.track}</p>

        <div className="flex items-center justify-between flex-wrap gap-4 pt-6 border-t border-brand-line">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-brand-sub mb-0.5">Issued</p>
            <p className="text-sm text-brand-ink font-medium">{cert.date}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-brand-sub mb-0.5">Certificate ID</p>
            <p className="font-mono text-sm text-brand-blue font-medium">{cert.id}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
