import Link from "next/link";
import { Lock, Clock, BarChart3 } from "lucide-react";

export default function CourseCard({ course }) {
  return (
    <Link
      href={`/course/${course.id}`}
      className="group relative flex flex-col bg-white border border-brand-line rounded-2xl p-5 hover:shadow-raised hover:-translate-y-0.5 transition-all duration-200"
    >
      {course.premium && (
        <span className="absolute top-4 right-4 flex items-center gap-1 text-[11px] font-semibold bg-amber-50 text-brand-amber border border-amber-200 rounded-full px-2 py-0.5">
          <Lock size={11} /> Premium
        </span>
      )}
      <span
        className="text-[11px] font-semibold uppercase tracking-wide mb-2"
        style={{ color: course.trackColor }}
      >
        {course.track}
      </span>
      <h3 className="font-display font-bold text-base text-brand-ink leading-snug mb-1.5 pr-16 group-hover:text-brand-blue transition-colors">
        {course.title}
      </h3>
      <p className="text-sm text-brand-sub leading-relaxed mb-4 line-clamp-2">{course.blurb}</p>
      <div className="mt-auto flex items-center gap-3 text-xs text-brand-sub">
        <span className="flex items-center gap-1"><Clock size={12} /> {course.hours}h</span>
        <span className="flex items-center gap-1"><BarChart3 size={12} /> {course.level}</span>
      </div>
    </Link>
  );
}
