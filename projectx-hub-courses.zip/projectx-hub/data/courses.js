import { TRACKS } from "./topics";
import flagship from "./flagshipCourses";

const LEVELS = ["Beginner", "Intermediate", "Advanced"];
const TOTAL_TARGET = 500;

function slugify(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

function otherTrackNames(track, count) {
  const others = TRACKS.filter(t => t.key !== track.key).map(t => t.name);
  const h = hashStr(track.key);
  const picked = [];
  for (let i = 0; i < count; i++) picked.push(others[(h + i * 7) % others.length]);
  return picked;
}

const GENERIC_WRONG = [
  "Ignoring the fundamentals entirely", "Skipping every practical exercise",
  "Guessing randomly without a strategy", "Memorizing terms without understanding them",
  "A completely unrelated skill set", "Avoiding real-world examples",
  "Copying answers without checking them", "None of the concepts covered in this course",
];

function withCorrectAt(correct, distractorPool, seed, poolOffset) {
  const options = [distractorPool[(seed + poolOffset) % distractorPool.length],
    distractorPool[(seed + poolOffset + 1) % distractorPool.length],
    distractorPool[(seed + poolOffset + 2) % distractorPool.length]];
  const idx = seed % 4;
  options.splice(idx, 0, correct);
  return { options: options.slice(0, 4), correct: idx };
}

function generateLessons(topic, track) {
  const [c0, c1, c2, c3] = track.concepts;
  const introTitle = /^introduction to/i.test(topic) ? topic : `Introduction to ${topic}`;
  return [
    {
      title: introTitle,
      content: [
        `${topic} is a core skill within ${track.name}. This course starts with ${c0}, giving you a working mental model before moving into anything advanced.`,
        `By the end of this lesson, you should be able to explain what ${topic} actually does in plain language — not just repeat the name.`,
      ],
    },
    {
      title: `Core Concepts of ${topic}`,
      content: [
        `Once the basics are clear, the real skill in ${topic} is understanding ${c1}. This is where most learners either build real intuition or fall back to memorizing without understanding.`,
        `Focus on the reasoning behind each concept, not just what it's called — that's what makes the knowledge usable outside this course.`,
      ],
    },
    {
      title: `Applying ${topic} in Practice`,
      content: [
        `Theory only matters if you can use it. This lesson covers ${c2} and ${c3} — the parts of ${topic} that show up constantly in real, practical work.`,
        `Try to connect each idea here to a real example from your own projects. That's what turns a course into an actual skill.`,
      ],
    },
  ];
}

function generateQuiz(topic, track, level, hours) {
  const h = hashStr(topic + track.key);
  const rows = [
    { q: `What is the main subject of this course?`, correct: topic, seed: h + 0 },
    { q: `Which ProjectX Hub track does this course belong to?`, correct: track.name, seed: h + 1, pool: otherTrackNames(track, 8) },
    { q: `What matters more than memorizing definitions when learning ${topic}?`, correct: "Understanding why each concept works, not just its name", seed: h + 2 },
    { q: `What does the first lesson of this course focus on?`, correct: `Building a working mental model of ${topic}`, seed: h + 3 },
    { q: `What does the second lesson emphasize?`, correct: `The reasoning behind ${topic}, not just repeating facts`, seed: h + 4 },
    { q: `What does the third lesson focus on?`, correct: `Applying ${topic} to real, practical situations`, seed: h + 5 },
    { q: `What's the best way to retain what you learn in this course?`, correct: "Connecting each idea to a real example from your own work", seed: h + 6 },
    { q: `What level is this course designed for?`, correct: level, seed: h + 7, pool: LEVELS.filter(l => l !== level).concat(["Expert-only", "No prior context needed"]) },
    { q: `Roughly how long is this course designed to take?`, correct: `${hours} hours`, seed: h + 8, pool: [`${hours + 3} hours`, `${Math.max(1, hours - 2)} hours`, `${hours + 8} hours`, `${hours + 1} hours`] },
    { q: `What is this course ultimately meant to build?`, correct: "Foundational, practical knowledge you can apply immediately", seed: h + 9 },
  ];
  return rows.map((r, i) => {
    const pool = r.pool && r.pool.length >= 3 ? r.pool : GENERIC_WRONG;
    const { options, correct } = withCorrectAt(r.correct, pool, r.seed, i);
    return { q: r.q, options, correct };
  });
}

function makeCourse(track, topic, titleOverride, variantIndex) {
  const title = titleOverride || topic;
  const id = `${track.key}-${slugify(title)}`;
  const h = hashStr(id);
  const level = LEVELS[(h + (variantIndex || 0)) % 3];
  const hours = 2 + (h % 8);
  const premium = h % 4 === 0; // ~25% of the catalog is premium

  const flagshipMatch = flagship.find(f => f.id === id) || flagship.find(f => f.id === `${track.key}-${slugify(topic)}` && !titleOverride);

  if (flagshipMatch) {
    return { ...flagshipMatch, trackKey: track.key, trackColor: track.color };
  }

  return {
    id,
    title,
    track: track.name,
    trackKey: track.key,
    trackColor: track.color,
    level,
    hours,
    premium,
    blurb: `A practical, self-paced course covering ${topic.toLowerCase()} — part of the ${track.name} track on ProjectX Hub.`,
    lessons: generateLessons(topic, track),
    quiz: generateQuiz(topic, track, level, hours),
    generated: true,
  };
}

function buildCatalog() {
  const list = [];

  TRACKS.forEach(track => {
    track.topics.forEach(topic => list.push(makeCourse(track, topic)));
  });

  // Pad up to TOTAL_TARGET with "Applied Practice" follow-on courses,
  // cycling through tracks/topics so every track keeps growing evenly.
  let i = 0;
  while (list.length < TOTAL_TARGET) {
    const track = TRACKS[i % TRACKS.length];
    const topic = track.topics[Math.floor(i / TRACKS.length) % track.topics.length];
    const variant = Math.floor(i / (TRACKS.length * track.topics.length)) + 2;
    const title = `${topic}: Applied Practice ${variant}`;
    list.push(makeCourse(track, topic, title, variant));
    i++;
  }

  return list.slice(0, TOTAL_TARGET);
}

let _catalog = null;
export function getAllCourses() {
  if (!_catalog) _catalog = buildCatalog();
  return _catalog;
}

export function getCourseById(id) {
  return getAllCourses().find(c => c.id === id);
}

export function getTracks() {
  return TRACKS.map(t => ({ key: t.key, name: t.name, color: t.color }));
}
