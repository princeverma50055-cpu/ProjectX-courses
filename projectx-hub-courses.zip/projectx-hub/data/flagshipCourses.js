// Flagship courses: fully written lessons + real 10-question quizzes.
// These override auto-generated placeholders with the same id.
// Add more over time — this is the highest-value way to grow the catalog.

const flagship = [
  {
    id: "ai-introduction-to-artificial-intelligence",
    title: "Introduction to Artificial Intelligence",
    track: "Artificial Intelligence",
    level: "Beginner",
    hours: 3,
    premium: false,
    blurb: "What AI actually is, how it differs from normal software, and where it's used today.",
    lessons: [
      {
        title: "What AI Actually Is",
        content: [
          "Artificial intelligence is software that makes decisions by learning patterns from data, instead of following instructions a programmer wrote line by line. A traditional program is given exact rules: if this, then that. An AI system is instead shown thousands or millions of examples, and it works out its own rules for how inputs connect to outputs.",
          "This distinction matters because it changes how these systems fail. A traditional program fails when the rules are wrong. An AI system fails when its training examples didn't cover a situation well, which is why AI can seem confident and be completely wrong at the same time — it's always pattern-matching, even when the pattern doesn't apply.",
        ],
      },
      {
        title: "The Three Things Every AI System Needs",
        content: [
          "Every AI system, no matter how advanced, needs three ingredients: data to learn from, a model architecture that can represent patterns in that data, and a training process that adjusts the model until its outputs match reality closely enough to be useful.",
          "Data quality matters more than model size in most real applications. A smaller model trained on clean, relevant data will usually beat a larger model trained on messy data. This is the opposite of what most beginners assume, and it's why data cleaning is often 70% of real AI work.",
        ],
      },
      {
        title: "Where AI Is Actually Used Today",
        content: [
          "AI already sits behind things you use daily without noticing: spam filters, product recommendations, autocomplete, fraud detection on your bank card, and the ranking of your social media feed. These are narrow AI systems — each one is good at exactly one task and cannot generalize beyond it.",
          "Large language models like the ones powering modern chatbots are a newer category: they're trained on broad text data and can handle many different tasks with the same underlying model, which is why they feel more general-purpose than older AI systems.",
        ],
      },
    ],
    quiz: [
      { q: "What is the main difference between traditional software and AI systems?", options: ["AI is always faster", "AI learns patterns from data instead of following pre-written rules", "Traditional software cannot use data at all", "There is no real difference"], correct: 1 },
      { q: "Why can an AI system be confidently wrong?", options: ["It is always malfunctioning", "It runs out of memory", "It's pattern-matching, and the pattern may not fit a new situation", "It refuses to answer"], correct: 2 },
      { q: "Which factor often matters more than model size for real-world results?", options: ["The color scheme of the app", "Data quality", "The programming language used", "The number of servers"], correct: 1 },
      { q: "What is a 'narrow AI' system?", options: ["An AI that is physically small", "An AI good at exactly one task, unable to generalize beyond it", "An AI that only works at night", "A broken AI model"], correct: 1 },
      { q: "What makes large language models feel more 'general-purpose'?", options: ["They are trained on broad text data and can handle many tasks", "They are only used for translation", "They cannot be updated", "They run without any data"], correct: 0 },
      { q: "Which of these is an everyday example of narrow AI?", options: ["A calculator app", "A spam filter", "A text editor", "A basic calendar app"], correct: 1 },
      { q: "What are the three core ingredients every AI system needs?", options: ["Data, a model architecture, and a training process", "A logo, a website, and a domain", "Electricity, a screen, and a keyboard", "Marketing, sales, and support"], correct: 0 },
      { q: "Why does data cleaning take up so much real AI work?", options: ["It's a legal requirement", "Model quality depends heavily on input data quality", "It's the only fun part of the job", "It has nothing to do with results"], correct: 1 },
      { q: "What happens to a traditional rule-based program when the rules are wrong?", options: ["It fixes itself automatically", "It fails, because it has no other way to behave", "It becomes an AI system", "Nothing changes"], correct: 1 },
      { q: "Which statement best describes the training process?", options: ["It's a one-time setup that never changes", "It adjusts the model until its outputs are useful enough", "It only applies to hardware, not software", "It replaces the need for any data"], correct: 1 },
    ],
  },
  {
    id: "ai-prompt-engineering",
    title: "Prompt Engineering",
    track: "Artificial Intelligence",
    level: "Beginner",
    hours: 4,
    premium: false,
    blurb: "How to write prompts that get consistently useful answers from any AI model.",
    lessons: [
      {
        title: "Why Prompts Fail",
        content: [
          "Most bad AI outputs are caused by vague prompts, not a weak model. When you ask 'write me something about marketing,' the model has to guess your audience, tone, length, and goal — and it will guess wrong more often than not.",
          "The fix is to treat a prompt like a brief you'd give a freelancer: state the task, the context, the constraints, and what a good result looks like. The more of that guesswork you remove, the more consistent your results become.",
        ],
      },
      {
        title: "The Four-Part Prompt Structure",
        content: [
          "A reliable structure is: role (who should the model act as), task (what exactly to produce), context (background facts it needs), and format (how the output should be shaped — length, tone, structure).",
          "For example, instead of 'write a product description,' a structured prompt says: 'You're an e-commerce copywriter. Write a 60-word product description for a stainless steel water bottle, targeting fitness-focused buyers, in an energetic tone, ending with a call to action.'",
        ],
      },
      {
        title: "Iterating Instead of Restarting",
        content: [
          "Treat the first response as a draft, not a final answer. Instead of rewriting your whole prompt when the output is close but not right, give targeted feedback: 'make it shorter,' 'remove the third point,' 'make the tone less formal.' Models handle incremental correction far better than a wall of new instructions.",
          "For anything with a factual answer, ask the model to show its reasoning or list its assumptions — this makes it much easier to spot where it went wrong.",
        ],
      },
    ],
    quiz: [
      { q: "What usually causes a bad AI output more than a weak model?", options: ["Server downtime", "A vague prompt", "Too much RAM", "Slow internet"], correct: 1 },
      { q: "What is a good way to think about writing a prompt?", options: ["Like a riddle", "Like a brief you'd give a freelancer", "Like a legal contract", "Like a search engine query only"], correct: 1 },
      { q: "What are the four parts of a reliable prompt structure?", options: ["Role, task, context, format", "Name, date, time, location", "Title, author, price, link", "Subject, verb, object, tone"], correct: 0 },
      { q: "In the four-part structure, what does 'role' refer to?", options: ["The user's job title", "Who the model should act as", "The file format", "The output length"], correct: 1 },
      { q: "What's the better approach when an output is close but not quite right?", options: ["Give targeted feedback on what to change", "Always start over from scratch", "Give up and try a different tool", "Repeat the exact same prompt"], correct: 0 },
      { q: "Why should you ask a model to show its reasoning for factual tasks?", options: ["It makes the response longer for no reason", "It makes it easier to spot where it went wrong", "It's required by law", "It slows down the response unnecessarily"], correct: 1 },
      { q: "What does 'format' control in a structured prompt?", options: ["The model's training data", "How the output is shaped — length, tone, structure", "The user's account settings", "The server location"], correct: 1 },
      { q: "Why do models handle incremental correction better than a full prompt rewrite?", options: ["They don't — full rewrites always work better", "Targeted feedback narrows down exactly what needs to change", "Incremental correction uses less electricity", "It's a myth with no real effect"], correct: 1 },
      { q: "What should you include in the 'context' part of a prompt?", options: ["Background facts the model needs", "Random unrelated trivia", "Your login password", "Nothing — context isn't necessary"], correct: 0 },
      { q: "Which of these is the most specific, well-structured prompt?", options: ["'Write something good'", "'Marketing please'", "'Write a 60-word product description for a water bottle, energetic tone, ending with a call to action'", "'Help me'"], correct: 2 },
    ],
  },
  {
    id: "web-html-fundamentals",
    title: "HTML Fundamentals",
    track: "Web Development",
    level: "Beginner",
    hours: 5,
    premium: false,
    blurb: "The building blocks of every web page, from tags to structure to semantic markup.",
    lessons: [
      {
        title: "What HTML Actually Does",
        content: [
          "HTML (HyperText Markup Language) describes the structure of a web page — what's a heading, what's a paragraph, what's a link — using tags. It does not control how things look; that's CSS's job. Think of HTML as the skeleton and CSS as the skin and clothes.",
          "A tag usually comes in a pair: an opening tag like <p> and a closing tag like </p>, wrapping the content they apply to. Some tags, like <img> and <br>, are self-closing because they don't wrap any content.",
        ],
      },
      {
        title: "The Core Tags You'll Use Constantly",
        content: [
          "Headings use <h1> through <h6>, from most to least important — a page should have exactly one <h1>. Paragraphs use <p>. Links use <a href=\"...\">, and images use <img src=\"...\" alt=\"...\">. Lists use <ul> for unordered (bulleted) and <ol> for ordered (numbered), with each item wrapped in <li>.",
          "The <div> tag is a generic container with no meaning of its own — useful for grouping and styling, but overusing it instead of meaningful tags makes pages harder to read for both humans and screen readers.",
        ],
      },
      {
        title: "Semantic HTML and Why It Matters",
        content: [
          "Semantic tags like <header>, <nav>, <main>, <article>, <section>, and <footer> describe the purpose of a section, not just its box shape. This helps search engines understand your page, helps screen readers navigate it for visually impaired users, and makes your own code easier to read months later.",
          "A good rule: if a more specific, meaningful tag exists for what you're building, use it instead of a plain <div>.",
        ],
      },
    ],
    quiz: [
      { q: "What does HTML control on a web page?", options: ["Colors and animations", "The structure and meaning of content", "Server logic", "Database storage"], correct: 1 },
      { q: "Which tool actually controls how a page looks visually?", options: ["HTML", "CSS", "A database", "A domain name"], correct: 1 },
      { q: "Why are <img> and <br> self-closing tags?", options: ["They're broken", "They don't wrap any content", "They're deprecated", "They require JavaScript"], correct: 1 },
      { q: "How many <h1> tags should a well-structured page typically have?", options: ["As many as possible", "Exactly one", "Zero", "At least ten"], correct: 1 },
      { q: "What does the <div> tag mean on its own?", options: ["Nothing — it's a generic container", "It always means 'important'", "It creates a link", "It creates a table"], correct: 0 },
      { q: "Which tag is used for an ordered (numbered) list?", options: ["<ul>", "<ol>", "<li>", "<div>"], correct: 1 },
      { q: "What is the purpose of semantic tags like <nav> and <footer>?", options: ["They make the page load faster automatically", "They describe the purpose of a section, aiding search engines and screen readers", "They are required for CSS to work", "They replace the need for JavaScript"], correct: 1 },
      { q: "Which attribute on <img> describes the image for screen readers?", options: ["src", "alt", "href", "class"], correct: 1 },
      { q: "What wraps each item inside a <ul> or <ol> list?", options: ["<item>", "<li>", "<p>", "<a>"], correct: 1 },
      { q: "What's the general rule for choosing between a semantic tag and a plain <div>?", options: ["Always use <div>, it's simpler", "Use the more specific, meaningful tag when one exists", "Never use semantic tags", "It never makes a difference"], correct: 1 },
    ],
  },
  {
    id: "web-javascript-fundamentals",
    title: "JavaScript Fundamentals",
    track: "Web Development",
    level: "Beginner",
    hours: 6,
    premium: false,
    blurb: "Variables, functions, and logic — the core of how web pages become interactive.",
    lessons: [
      {
        title: "Variables and Values",
        content: [
          "JavaScript stores data in variables, declared with let, const, or the older var. Use const when a value won't be reassigned, and let when it will. Avoid var in new code — it behaves inconsistently with scope compared to let and const.",
          "Values have types: strings ('text'), numbers (42), booleans (true/false), arrays ([1,2,3]), and objects ({key: 'value'}). JavaScript is dynamically typed, meaning a variable's type can change at runtime, which is flexible but also a common source of bugs.",
        ],
      },
      {
        title: "Functions and Logic",
        content: [
          "A function is a reusable block of code: function greet(name) { return 'Hello ' + name; }. Modern JavaScript also uses arrow functions: const greet = (name) => 'Hello ' + name;, which are shorter and handle the 'this' keyword differently — important once you work with objects and classes.",
          "Conditional logic (if/else) and loops (for, while) control the flow of a program. The most common loop in modern JavaScript for arrays is .forEach() or .map(), which are often clearer than a manual for loop for simple iteration.",
        ],
      },
      {
        title: "The DOM: Connecting JavaScript to the Page",
        content: [
          "The Document Object Model (DOM) is how JavaScript reads and changes what's on the page. document.querySelector('.button') finds an element, and .addEventListener('click', function) makes it respond to a user action.",
          "This event-driven model — code that waits for something to happen instead of running top-to-bottom once — is the foundation of every interactive website, from a simple button to a full web app.",
        ],
      },
    ],
    quiz: [
      { q: "When should you use const instead of let?", options: ["When the value will be reassigned later", "When the value won't be reassigned", "Never — always use var", "Only for numbers"], correct: 1 },
      { q: "What does it mean that JavaScript is 'dynamically typed'?", options: ["It only works with numbers", "A variable's type can change at runtime", "It cannot store text", "Types must be declared manually every time"], correct: 1 },
      { q: "Which of these is a valid arrow function?", options: ["function => name", "const greet = (name) => 'Hello ' + name;", "arrow greet(name) {}", "let greet == name =>"], correct: 1 },
      { q: "What does document.querySelector do?", options: ["Deletes an element", "Finds an element on the page", "Creates a new webpage", "Sends data to a server"], correct: 1 },
      { q: "What is the DOM?", options: ["A database system", "How JavaScript reads and changes what's on the page", "A CSS framework", "A type of server"], correct: 1 },
      { q: "What does .addEventListener('click', function) do?", options: ["Deletes the click event", "Makes an element respond to a click action", "Changes the page background", "Loads a new script file"], correct: 1 },
      { q: "Why is 'event-driven' code useful for websites?", options: ["It makes the page load slower", "It lets code wait and respond to user actions instead of running once, top to bottom", "It removes the need for HTML", "It only works on mobile"], correct: 1 },
      { q: "Which is a common issue with using var in modern code?", options: ["It's faster than let", "It behaves inconsistently with scope compared to let/const", "It cannot store strings", "It doesn't exist in JavaScript"], correct: 1 },
      { q: "Which data type represents true/false values?", options: ["String", "Boolean", "Array", "Object"], correct: 1 },
      { q: "Which method is commonly used to loop through array items in modern JS?", options: [".forEach()", ".delete()", ".connect()", ".render()"], correct: 0 },
    ],
  },
  {
    id: "programming-python-for-beginners",
    title: "Python for Beginners",
    track: "Programming",
    level: "Beginner",
    hours: 6,
    premium: false,
    blurb: "Start writing real Python — syntax, logic, and your first working scripts.",
    lessons: [
      {
        title: "Why Python Reads Like English",
        content: [
          "Python was deliberately designed to be readable. Instead of curly braces to define code blocks, Python uses indentation — meaning how your code is spaced isn't just a style choice, it's part of the syntax. Get the indentation wrong and the program breaks.",
          "A basic script: name = input('What is your name? ') then print(f'Hello, {name}!') — this reads almost like a sentence, which is exactly the point.",
        ],
      },
      {
        title: "Core Data Types and Structures",
        content: [
          "Python's core types are int, float, str, bool, list, dict, and tuple. A list ([1, 2, 3]) holds ordered items you can change. A dictionary ({'name': 'Prince', 'age': 17}) stores key-value pairs, which is how you'll represent most real-world data — a user, a product, a course.",
          "Loops (for item in list:) and conditionals (if/elif/else) control logic, and functions (def my_function():) let you package logic into reusable, testable pieces.",
        ],
      },
      {
        title: "Writing Your First Useful Script",
        content: [
          "Real automation usually follows the same pattern: read some input (a file, user input, or an API), process it (loop, filter, transform), and produce an output (print it, save it, send it somewhere). A file-renaming script, a to-do list, or a simple grade calculator are all built on this same three-step pattern.",
          "Learning to break a bigger problem into these three steps — input, process, output — is a more valuable skill than memorizing syntax, because it transfers to every language you'll ever learn.",
        ],
      },
    ],
    quiz: [
      { q: "What defines a code block in Python instead of curly braces?", options: ["Semicolons", "Indentation", "Capital letters", "Parentheses"], correct: 1 },
      { q: "What happens if Python indentation is incorrect?", options: ["Nothing, it's ignored", "The program breaks", "It runs faster", "It auto-corrects"], correct: 1 },
      { q: "Which data type stores key-value pairs in Python?", options: ["list", "dict", "tuple", "int"], correct: 1 },
      { q: "What is a list in Python best used for?", options: ["Storing a single number", "Holding ordered items that can change", "Running a loop only", "Defining a function"], correct: 1 },
      { q: "What keyword starts a function definition in Python?", options: ["func", "define", "def", "function"], correct: 2 },
      { q: "What is the general three-step pattern behind most automation scripts?", options: ["Design, test, deploy", "Input, process, output", "Login, edit, save", "Plan, build, ship"], correct: 1 },
      { q: "Why is learning to break a problem into input/process/output valuable?", options: ["It only works in Python", "It transfers to every programming language", "It's required by law", "It only applies to websites"], correct: 1 },
      { q: "Which of these correctly represents a Python dictionary?", options: ["[1, 2, 3]", "{'name': 'Prince', 'age': 17}", "(1, 2, 3)", "'name, age'"], correct: 1 },
      { q: "What is Python's design philosophy generally focused on?", options: ["Maximum complexity", "Readability", "Requiring semicolons everywhere", "Avoiding functions"], correct: 1 },
      { q: "Which statement is used for conditional logic in Python?", options: ["if/elif/else", "loop/end", "case/switch only", "try/catch only"], correct: 0 },
    ],
  },
  {
    id: "business-zero-budget-business-launch",
    title: "Zero-Budget Business Launch",
    track: "Business",
    level: "Beginner",
    hours: 4,
    premium: false,
    blurb: "How to validate, launch, and land paying customers before you spend a rupee.",
    lessons: [
      {
        title: "Validate Before You Build",
        content: [
          "The single most common founder mistake is building first and validating second. Validation means confirming someone will actually pay for a solution before you spend weeks building it — by pre-selling, running a simple landing page, or directly asking potential customers what they're currently doing to solve the problem and what they'd pay to solve it better.",
          "If you can't get five people to say 'yes, I'd pay for that' before you build anything, building it won't fix that problem — it'll just delay finding out.",
        ],
      },
      {
        title: "Your First Product Doesn't Need Code",
        content: [
          "A 'concierge MVP' means you manually deliver the result the software would eventually automate. If your idea is an AI resume-review tool, you can review resumes yourself first, using AI tools as your own back-end, and charge for it immediately. This proves demand and teaches you exactly what to automate later.",
          "Free tools cover almost everything a zero-budget launch needs: a form (Google Forms), a landing page (Carrd or a simple GitHub Pages site), payments (UPI, direct), and outreach (your existing social accounts).",
        ],
      },
      {
        title: "Getting Your First Ten Customers",
        content: [
          "Cold, broad marketing rarely works at zero budget. What works is going where your exact potential customer already is — a specific subreddit, a Discord server, a WhatsApp group, or your own network — and offering direct, personal value, not a generic pitch.",
          "Your first ten customers should come from direct outreach, not ads. Once you understand exactly why they said yes, you can turn that reason into repeatable marketing.",
        ],
      },
    ],
    quiz: [
      { q: "What is the most common mistake first-time founders make?", options: ["Pricing too low", "Building before validating demand", "Hiring too fast", "Using free tools"], correct: 1 },
      { q: "What does 'validation' mean in this context?", options: ["Getting a business license", "Confirming someone will actually pay before you build", "Registering a domain name", "Designing a logo"], correct: 1 },
      { q: "What is a 'concierge MVP'?", options: ["A luxury version of your product", "Manually delivering the result before automating it", "A paid ad campaign", "A legal document"], correct: 1 },
      { q: "Why does a concierge MVP help you later?", options: ["It has no benefit", "It proves demand and shows exactly what to automate", "It replaces the need for customers", "It's only useful for restaurants"], correct: 1 },
      { q: "According to the lesson, what usually doesn't work at zero budget?", options: ["Direct outreach", "Cold, broad marketing", "Talking to potential customers", "Using free tools"], correct: 1 },
      { q: "Where should you look for your first customers?", options: ["Random cold-calling", "Where your exact potential customer already spends time", "Nowhere — wait for them to find you", "Only paid ad platforms"], correct: 1 },
      { q: "What is a practical zero-cost way to test a landing page?", options: ["Hire a design agency", "Use a free tool like Carrd or GitHub Pages", "Buy a premium website builder plan", "Skip it entirely"], correct: 1 },
      { q: "What's a strong signal that you've validated demand?", options: ["Getting likes on a social post", "Getting people to actually say yes and pay before you build", "Getting a lot of followers", "Getting positive feedback with no commitment"], correct: 1 },
      { q: "What should you do once you know why your first customers said yes?", options: ["Ignore it and move on", "Turn that reason into repeatable marketing", "Change your product completely", "Stop talking to customers"], correct: 1 },
      { q: "What payment method does the lesson suggest for zero-budget founders in India?", options: ["Only cash", "Direct UPI", "Cryptocurrency only", "Cheques"], correct: 1 },
    ],
  },
  {
    id: "cyber-cybersecurity-essentials",
    title: "Cybersecurity Essentials",
    track: "Cybersecurity",
    level: "Beginner",
    hours: 4,
    premium: false,
    blurb: "Core threats, defenses, and how attackers actually think.",
    lessons: [
      {
        title: "How Attackers Actually Think",
        content: [
          "Most attacks aren't sophisticated — they target the easiest available weakness, not the strongest system. An attacker generally follows a pattern: find a target, look for an opening (a weak password, an unpatched system, a careless click), get in, and then try to expand access or extract value.",
          "This is why security isn't about being unhackable — it's about making yourself a harder, less appealing target than the next one, and detecting an intrusion fast when prevention fails.",
        ],
      },
      {
        title: "The Threats You'll Actually Encounter",
        content: [
          "Phishing — fake messages designed to trick you into giving up credentials or clicking a malicious link — remains the most common entry point for real breaches, because it targets people, not code. Malware, weak or reused passwords, and unpatched software round out the most common causes.",
          "Social engineering is the umbrella term for manipulating people rather than systems: impersonating IT support, creating false urgency, or exploiting trust. Technical defenses can't fully stop this — awareness is the actual defense.",
        ],
      },
      {
        title: "Practical Defenses That Actually Work",
        content: [
          "Unique passwords per account (via a password manager) plus two-factor authentication block the majority of account takeovers, even against a leaked password. Keeping software updated closes known vulnerabilities before attackers can use them — most breaches exploit gaps that had a patch available for months.",
          "For anything sensitive, verify unusual requests through a second channel — if an urgent 'payment needed' message comes by email, confirm by phone before acting. This single habit stops most social engineering attempts cold.",
        ],
      },
    ],
    quiz: [
      { q: "What do most real-world attacks target?", options: ["The strongest system available", "The easiest available weakness", "Only large companies", "Random systems with no pattern"], correct: 1 },
      { q: "What is the actual goal of practical security, according to the lesson?", options: ["Becoming completely unhackable", "Being a harder target and detecting intrusions fast", "Avoiding the internet entirely", "Only using expensive tools"], correct: 1 },
      { q: "What is phishing?", options: ["A type of firewall", "Fake messages designed to trick you into giving up credentials", "A programming language", "A kind of antivirus software"], correct: 1 },
      { q: "Why is phishing so common as an attack method?", options: ["It targets people, not code", "It requires advanced hacking skills", "It only works on old computers", "It's illegal to defend against"], correct: 0 },
      { q: "What is social engineering?", options: ["Designing social media apps", "Manipulating people rather than systems", "A type of encryption", "A hardware security feature"], correct: 1 },
      { q: "What actually stops most social engineering attempts?", options: ["Faster internet", "Awareness and verifying requests through a second channel", "More RAM", "Ignoring all messages"], correct: 1 },
      { q: "What combination blocks the majority of account takeovers?", options: ["A memorable password only", "Unique passwords plus two-factor authentication", "Sharing passwords with trusted friends", "Never logging in"], correct: 1 },
      { q: "Why does keeping software updated matter for security?", options: ["It's purely cosmetic", "It closes known vulnerabilities attackers could exploit", "It has no security benefit", "It only affects speed"], correct: 1 },
      { q: "What is the general pattern an attacker follows?", options: ["Find a target, find an opening, get in, expand access", "Only work during business hours", "Always use brute force first", "Attack randomly with no plan"], correct: 0 },
      { q: "If you get an urgent payment request by email, what should you do?", options: ["Act immediately without question", "Verify it through a second channel like a phone call", "Forward it to everyone", "Ignore all emails permanently"], correct: 1 },
    ],
  },
  {
    id: "marketing-high-cpm-content-strategy",
    title: "High-CPM Content Strategy",
    track: "Marketing",
    level: "Intermediate",
    hours: 3,
    premium: true,
    blurb: "Writing and distributing content that platforms and advertisers actually reward.",
    lessons: [
      {
        title: "Why CPM Varies So Much by Niche",
        content: [
          "CPM (cost per thousand impressions) reflects what advertisers are willing to pay to reach a specific audience — it isn't about your content quality alone. Niches like finance, business software (SaaS), cybersecurity, and enterprise technology carry high CPMs because the audience has real buying power and advertisers in those categories pay a premium to reach them.",
          "This is why two creators with identical view counts can earn very different amounts: one is reaching an audience advertisers barely value, the other is reaching decision-makers with budgets.",
        ],
      },
      {
        title: "Structuring Content for Retention, Not Just Clicks",
        content: [
          "Platforms reward content that keeps people watching or reading, not just content that gets an initial click. A strong hook earns the click; a clear structure (a promise, a build-up, a payoff) earns the rest of the read or watch, and retention is what the algorithm actually optimizes for.",
          "Practically, this means: state the value in the first line, deliver information in a logical build rather than a vague ramble, and end with a clear takeaway — not a sudden stop.",
        ],
      },
      {
        title: "Distribution: One Piece, Many Formats",
        content: [
          "High-output creators rarely write something new for every platform. They create one substantial piece — a blog post, a case study, a deep thread — and reformat it: the thread becomes a LinkedIn post, the LinkedIn post becomes three short posts, one insight becomes a Bluesky post. This multiplies output without multiplying research time.",
          "Consistency compounds faster than virality. A steady publishing schedule in a high-CPM niche will usually outperform sporadic viral hits over a 6-month period, because it builds a returning audience advertisers value more predictably.",
        ],
      },
    ],
    quiz: [
      { q: "What does CPM actually reflect?", options: ["Content quality alone", "What advertisers pay to reach a specific audience", "The creator's follower count", "The platform's server costs"], correct: 1 },
      { q: "Why do niches like finance and enterprise SaaS have high CPMs?", options: ["They're easier to make content about", "The audience has real buying power advertisers pay to reach", "They require less effort", "They have fewer creators"], correct: 1 },
      { q: "What do platforms actually optimize for, beyond the initial click?", options: ["Video file size", "Retention — how long people keep watching or reading", "Number of hashtags used", "Upload time of day only"], correct: 1 },
      { q: "What does a strong hook accomplish?", options: ["Nothing measurable", "It earns the initial click", "It guarantees virality", "It replaces the need for good content"], correct: 1 },
      { q: "What is the recommended content structure for retention?", options: ["Random order with no structure", "A promise, a build-up, a payoff", "Only a title with no body", "A list with no context"], correct: 1 },
      { q: "What does 'one piece, many formats' mean in distribution strategy?", options: ["Writing something entirely new for every platform", "Reformatting one substantial piece across multiple platforms", "Posting the exact same image everywhere", "Only using one platform ever"], correct: 1 },
      { q: "Why does this repurposing approach help creators?", options: ["It multiplies output without multiplying research time", "It has no real benefit", "It only works for video", "It reduces content quality"], correct: 0 },
      { q: "According to the lesson, what usually outperforms sporadic viral hits over 6 months?", options: ["Paid ads only", "A steady, consistent publishing schedule", "Posting once a year", "Buying followers"], correct: 1 },
      { q: "Why can two creators with the same view count earn very different amounts?", options: ["One is lying about their views", "They're reaching audiences advertisers value differently", "View counts are always fake", "It's completely random"], correct: 1 },
      { q: "What should the first line of a high-performing piece of content do?", options: ["State the value clearly", "Apologize for the length", "List unrelated facts", "Ask an unrelated question"], correct: 0 },
    ],
  },
  {
    id: "data-data-analysis-fundamentals",
    title: "Data Analysis Fundamentals",
    track: "Data Science",
    level: "Beginner",
    hours: 4,
    premium: false,
    blurb: "How to go from raw numbers to a decision you can actually trust.",
    lessons: [
      {
        title: "Data Before Insight: Cleaning",
        content: [
          "Raw data is almost never ready to analyze. Duplicate rows, missing values, inconsistent formatting (like '2024-01-01' next to '1/1/24'), and outliers caused by data entry errors will quietly distort every conclusion drawn from uncleaned data.",
          "A reliable habit: before analyzing anything, check row counts, check for duplicates, check for missing values, and check that each column's data type makes sense. Skipping this step is the single most common cause of a wrong conclusion presented with total confidence.",
        ],
      },
      {
        title: "Averages Lie: Understanding Distribution",
        content: [
          "The average (mean) can be badly distorted by a few extreme values — if nine people earn ₹20,000 and one earns ₹2,000,000, the average income looks nothing like what almost everyone actually earns. The median (the middle value) is often a more honest summary for skewed data like income, prices, or delivery times.",
          "Always ask: does this pattern hold for most individual cases, or is it being driven by a small number of extreme ones? Looking at a distribution, not just a single summary number, answers this.",
        ],
      },
      {
        title: "Correlation Is Not Causation",
        content: [
          "Two things moving together doesn't mean one causes the other — both could be caused by a third factor, or the relationship could be coincidental. Ice cream sales and drowning incidents both rise in summer; ice cream doesn't cause drowning, heat causes both.",
          "Before presenting a finding as actionable, ask what else could explain the pattern. This single question prevents most bad data-driven decisions.",
        ],
      },
    ],
    quiz: [
      { q: "What is often the most common cause of a confidently wrong conclusion?", options: ["Using too many charts", "Skipping the data cleaning step", "Using the median instead of the mean", "Working too slowly"], correct: 1 },
      { q: "What can badly distort a simple average?", options: ["A perfectly clean dataset", "A few extreme values", "Using a spreadsheet", "Rounding numbers"], correct: 1 },
      { q: "Why is the median often more honest for skewed data like income?", options: ["It's always a bigger number", "It represents the middle value, less affected by extremes", "It's easier to calculate", "It ignores all data points"], correct: 1 },
      { q: "What does 'correlation is not causation' mean?", options: ["Two things moving together doesn't prove one causes the other", "Correlated data is always wrong", "Causation is impossible to prove ever", "Correlation and causation are the same thing"], correct: 0 },
      { q: "In the ice cream and drowning example, what actually causes both to rise?", options: ["Ice cream itself", "Heat/summer weather", "Coincidence with no explanation", "Drowning causes ice cream sales"], correct: 1 },
      { q: "What should you check before analyzing any raw dataset?", options: ["Nothing, just start analyzing", "Duplicates, missing values, and inconsistent formatting", "Only the file size", "The color of the spreadsheet"], correct: 1 },
      { q: "What question helps prevent bad data-driven decisions?", options: ["What color should the chart be?", "What else could explain this pattern?", "How many people will like this?", "Is this data recent?"], correct: 1 },
      { q: "What issue can inconsistent date formatting cause?", options: ["No real issue", "Distorted analysis and errors when data is combined", "Faster processing", "Automatic correction by the software"], correct: 1 },
      { q: "Why should you look at a distribution instead of just one summary number?", options: ["It looks nicer in a report", "It shows whether a pattern holds for most cases or just a few extremes", "It's required by every tool", "It replaces the need for cleaning data"], correct: 1 },
      { q: "What is an 'outlier' most likely to be caused by, in many real datasets?", options: ["Always fraud", "Often a data entry error or unusual but real case", "Nothing — outliers should always be deleted", "A sign the whole dataset is fake"], correct: 1 },
    ],
  },
  {
    id: "design-ui-design-fundamentals",
    title: "UI Design Fundamentals",
    track: "Design",
    level: "Beginner",
    hours: 3,
    premium: false,
    blurb: "How good interfaces guide attention, reduce friction, and feel effortless to use.",
    lessons: [
      {
        title: "Hierarchy: Telling the Eye Where to Go",
        content: [
          "Visual hierarchy means the most important thing on a screen should look the most important — through size, weight, color, or position. If everything is emphasized equally (bold, colorful, large), nothing actually stands out, and the user has to work to figure out what matters.",
          "A simple test: squint at your screen until details blur. If you can still tell what the primary action is, your hierarchy is working.",
        ],
      },
      {
        title: "Spacing Is Not Empty Space",
        content: [
          "Consistent spacing (using a scale like 4px, 8px, 16px, 24px, 32px rather than random values) is what makes an interface feel calm and organized rather than cramped. Related items should sit closer together than unrelated ones — this alone communicates grouping without needing a visible border.",
          "Generous whitespace around a primary action makes it feel more important, the same way a single product on an empty shelf draws more attention than one crowded among ten others.",
        ],
      },
      {
        title: "Consistency Builds Trust",
        content: [
          "Using the same button style, spacing, and color meaning throughout an interface (green always means success, red always means danger) lets users predict how the interface will behave, which reduces the mental effort of using it. Inconsistency — even small, like three slightly different blues — quietly signals a lack of care, even if users can't articulate why.",
          "Google's own products are a strong reference for this: consistent spacing, restrained color use tied to meaning, and clear typographic hierarchy across very different products.",
        ],
      },
    ],
    quiz: [
      { q: "What does visual hierarchy mean?", options: ["Making everything the same size", "The most important thing should visually stand out most", "Using as many colors as possible", "Arranging items alphabetically"], correct: 1 },
      { q: "What happens if everything on a screen is equally emphasized?", options: ["The design becomes clearer", "Nothing actually stands out", "Users read faster", "It automatically becomes more accessible"], correct: 1 },
      { q: "What is the 'squint test' used for?", options: ["Testing eyesight", "Checking whether the primary action is still visually clear", "Measuring screen brightness", "Testing loading speed"], correct: 1 },
      { q: "What is a spacing scale (like 4px, 8px, 16px) used for?", options: ["Making spacing consistent instead of random", "Slowing down development", "Only for mobile apps", "Replacing color choices"], correct: 0 },
      { q: "How does spacing communicate grouping?", options: ["It doesn't", "Related items placed closer together read as connected", "Only borders can show grouping", "By using different fonts"], correct: 1 },
      { q: "Why does generous whitespace around a primary action help?", options: ["It hides the action", "It makes the action feel more important, like a product alone on a shelf", "It has no effect on attention", "It only matters on desktop"], correct: 1 },
      { q: "What does consistent color meaning (green = success, red = danger) achieve?", options: ["Nothing meaningful", "Lets users predict interface behavior, reducing mental effort", "Makes the interface slower", "Is purely decorative"], correct: 1 },
      { q: "What can small inconsistencies (like three slightly different blues) signal?", options: ["Extra attention to detail", "A lack of care, even if users can't articulate why", "Better accessibility", "Faster load times"], correct: 1 },
      { q: "What is one thing Google's products are noted for in this lesson?", options: ["Random colors everywhere", "Consistent spacing and restrained, meaningful color use", "No typography hierarchy at all", "Avoiding whitespace"], correct: 1 },
      { q: "What is the main goal of good UI hierarchy and spacing together?", options: ["To make the interface look busy", "To reduce user effort and guide attention naturally", "To use every available color", "To fill all empty space with content"], correct: 1 },
    ],
  },
  {
    id: "cloud-cloud-computing-fundamentals",
    title: "Cloud Computing Fundamentals",
    track: "Cloud Computing",
    level: "Beginner",
    hours: 3,
    premium: false,
    blurb: "What 'the cloud' actually is, and how modern apps get deployed and scaled.",
    lessons: [
      {
        title: "The Cloud Is Just Someone Else's Computer, Rented",
        content: [
          "Cloud computing means renting computing power, storage, and services from a provider (like AWS, Google Cloud, or Vercel) instead of buying and maintaining physical servers yourself. You pay for what you use, and the provider handles the physical hardware, power, and networking.",
          "This matters for small teams especially: you can launch a product that scales to millions of users without ever owning a server, and you only pay more as usage actually grows.",
        ],
      },
      {
        title: "Types of Cloud Services",
        content: [
          "IaaS (Infrastructure as a Service) gives you raw virtual servers you configure yourself — maximum control, maximum responsibility. PaaS (Platform as a Service), like Vercel or Render, handles the server setup for you — you just deploy your code. SaaS (Software as a Service) is a finished product you use directly, like Gmail.",
          "Most small teams and solo founders should default to PaaS: it removes server management entirely, letting you focus on the product instead of infrastructure.",
        ],
      },
      {
        title: "Scaling and Reliability",
        content: [
          "'Scaling' means handling more traffic without breaking. Horizontal scaling adds more machines to share the load; vertical scaling makes one machine more powerful. Modern cloud platforms mostly handle this automatically for you if your app is built statelessly — meaning any server instance can handle any request without needing to remember previous ones.",
          "Reliability comes from redundancy: cloud providers run your app across multiple physical locations, so if one fails, traffic shifts elsewhere without users noticing — something a single self-hosted server can't do on its own.",
        ],
      },
    ],
    quiz: [
      { q: "What does cloud computing fundamentally mean?", options: ["Owning your own physical servers", "Renting computing power and services from a provider", "Only storing photos online", "A type of programming language"], correct: 1 },
      { q: "What is a key benefit of cloud computing for small teams?", options: ["They must buy expensive hardware upfront", "They can scale without ever owning a server", "It removes the need for any code", "It only works for large companies"], correct: 1 },
      { q: "What does IaaS give you?", options: ["A finished software product", "Raw virtual servers you configure yourself", "Nothing — it's not a real category", "Only storage, no compute"], correct: 1 },
      { q: "What does PaaS handle for you that IaaS doesn't?", options: ["Nothing, they're identical", "Server setup, so you just deploy your code", "Your entire business model", "Marketing and sales"], correct: 1 },
      { q: "Which of these is an example of a PaaS platform mentioned in the lesson?", options: ["Vercel", "Microsoft Word", "A USB drive", "A physical server rack"], correct: 0 },
      { q: "What should most small teams or solo founders default to?", options: ["IaaS, for maximum manual control", "PaaS, to avoid managing servers directly", "Buying physical servers", "SaaS only, with no custom app"], correct: 1 },
      { q: "What does 'horizontal scaling' mean?", options: ["Making one machine more powerful", "Adding more machines to share the load", "Reducing the number of servers", "Changing the app's color scheme"], correct: 1 },
      { q: "What does it mean for an app to be built 'statelessly'?", options: ["It has no code", "Any server instance can handle any request without remembering previous ones", "It only runs once and stops", "It requires a single dedicated server"], correct: 1 },
      { q: "How do cloud providers typically achieve reliability?", options: ["By using only one server location", "By running apps across multiple physical locations (redundancy)", "By avoiding backups entirely", "By limiting how many users can connect"], correct: 1 },
      { q: "What happens if one location fails in a well-architected cloud setup?", options: ["The whole app goes down permanently", "Traffic shifts elsewhere without users noticing", "Nothing can be done", "The provider refunds all customers"], correct: 1 },
    ],
  },
];

export default flagship;
