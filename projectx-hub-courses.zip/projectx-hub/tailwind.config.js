/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: "#1A73E8",
          green: "#188038",
          amber: "#E37400",
          red: "#D93025",
          ink: "#202124",
          sub: "#5F6368",
          line: "#E8EAED",
          surface: "#F8F9FA",
        },
      },
      fontFamily: {
        display: ["'Google Sans'", "'Product Sans'", "Inter", "system-ui", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px 0 rgba(60,64,67,0.08), 0 1px 3px 1px rgba(60,64,67,0.08)",
        raised: "0 1px 3px 0 rgba(60,64,67,0.12), 0 4px 8px 3px rgba(60,64,67,0.08)",
      },
    },
  },
  plugins: [],
};
